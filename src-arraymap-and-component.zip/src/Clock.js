import React from 'react';
import Curenttime from './Curenttime';
import Calculator from './Calculator';

function Clock(){

  return (
      
        <div>
           
           <h3>Hello, <Curenttime /></h3>


            <Calculator />
                 
        </div>
     
       )

}

export default Clock;