import React from 'react';
import logo from './logo.svg';
import './App.css';
import Clock from './Clock';
import Card from './Card'
import data from './Card.jsx'



function App() {
  return (
  
    <div className="App"> 
    
    <Clock />

    {data.map( function (value)
                 {
                return (  <Card  name={value.name} image={value.image} /> );
                          
                 }
    )
      }


      { data.map(function(val)
      {
        return (<Card name={val.name} />);
      }) }
  
    

    </div>
   
  



);
                        }


export default App;
