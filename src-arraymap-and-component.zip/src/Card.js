import React from 'react';
import card from './card.css';

function Card(prps)
{

    return (
        <div className="Card">
            <div>
                <img width="250" src={prps.image} alt={prps.name} />    
            </div>            
                <h3>{prps.name}</h3>
        </div>
    );
}

export default Card;
