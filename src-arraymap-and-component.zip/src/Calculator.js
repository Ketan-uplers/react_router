import React from 'react';


function sub(one,two)
{
   return one + two;
}

function divi(one,two)
{
   return one / two;
}
function subs(one,two)
{
   return one - two;
}
function mult(one,two)
{
   return one * two;
}
function Calculator()
{

    return (
        <ul>
        <li>  Adition = {sub(10,20)}</li>
    <li> Division = {divi(10,20)}</li>
        <li> Subscription = {subs(10,20)} </li>
        <li> Multiplication= {mult(10,20)} </li>
        </ul>
    );
}

export default Calculator;