import React from 'react';



function Curenttime()
{
let curdat = new Date();
const cssStyle={};

curdat = curdat.getHours();
let get_msg='';
if(curdat >1 && curdat<12)
       {
        get_msg ='Good morning';
        cssStyle.color ="#900"
       }
       if(curdat >=12 && curdat<20)
       {
        get_msg ='Good Afternoon';
        cssStyle.color ="#090"
       }
       if(curdat >=20 && curdat<=24)
       {
        get_msg ='Good Night';
        cssStyle.color ="#009"
       }
return (
  
    <span style={cssStyle}>{get_msg}</span>
);

}


export default Curenttime;