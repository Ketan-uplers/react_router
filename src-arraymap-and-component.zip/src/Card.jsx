const data =[
{
    name:'ketan',
    image:'https://www.uplers.com/wp-content/themes/uplers/assets/images/about-img.png'
   },
   {
       name:'Nancy',
       image:'https://www.uplers.com/wp-content/themes/uplers/assets/images/about-img.png'
   },
   ,
   {
       name:'Uday',
       image:'https://www.uplers.com/wp-content/themes/uplers/assets/images/about-img.png'
   },
   ,
   {
       name:'Abhishek',
       image:'https://www.uplers.com/wp-content/themes/uplers/assets/images/about-img.png'
   }
];

export default data;