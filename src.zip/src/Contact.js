import React from 'react';
import './Aboutstyle.css';

const Contact = () =>{

        return (
                <div className="Contactstyle">
                    <h2>Whel come To  Contact us page</h2>
                    Contact
                </div>

        )

}

export default Contact;