import React from 'react';
import './Aboutstyle.css';

const About = () =>{

        return (
                <div className="Aboutstyle">
                    <h2>Whel come To  About us page</h2>

                </div>

        )

}

export default About;