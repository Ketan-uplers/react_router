import React from 'react';
import './Aboutstyle.css';

const Home = () =>{

        return (
                <div className="Aboutstyle">
                    <h2>Whel come To Home page</h2>
                    Contact
                </div>

        )

}

export default Home; 